"use strict";
/**
 * @lekzasoft/api: client resmi Lekzasoft API.
 *
 *   import api from "@lekzasoft/api";
 *   const play = await api("play", "dewa 19 kangen");
 *   console.log(play.title, play.file);
 *   await play.download("./musik");
 *
 * Tanpa dependensi, butuh Node.js 18+ (fetch bawaan).
 */
const fs = require("node:fs");
const path = require("node:path");
const { Readable } = require("node:stream");
const { pipeline } = require("node:stream/promises");

const VERSION = "1.0.0";
const DEFAULT_BASE_URL = "https://api.lekzasoft.web.id";
const DEFAULT_TOKEN = "PUBLIC-KEY"; // key publik bersama (kuota terbatas), ganti dengan token sendiri
const DEFAULT_TIMEOUT = 10 * 60 * 1000; // video panjang bisa makan waktu lama

// Kalau dua kategori punya nama sama (mis. "tiktok"), kategori paling kiri yang menang.
const CATEGORY_ORDER = ["downloaders", "tools", "searchs", "stalks", "funs"];
const ALIASES = { twitter: "x", "twitter-x": "x", ig: "instagram", fb: "facebook" };
const RESERVED = new Set(["download", "filename", "token", "timeout", "signal", "raw", "baseUrl", "method"]);

// [path, method], diambil dari daftar endpoint publik. api.sync() memperbaruinya dari server.
const BUILTIN = [
    ["downloaders/allinone", "GET"],
    ["downloaders/play", "GET"],
    ["downloaders/yts", "GET"],
    ["downloaders/ytmp3", "GET"],
    ["downloaders/ytmp4", "GET"],
    ["downloaders/ytmp3v2", "GET"],
    ["downloaders/ytmp4v2", "GET"],
    ["downloaders/tiktok", "GET"],
    ["downloaders/instagram", "GET"],
    ["downloaders/facebook", "GET"],
    ["downloaders/x", "GET"],
    ["downloaders/reddit", "GET"],
    ["downloaders/twitch", "GET"],
    ["downloaders/capcut", "GET"],
    ["downloaders/cocofun", "GET"],
    ["downloaders/douyin", "GET"],
    ["downloaders/gdrive", "GET"],
    ["downloaders/kuaishou", "GET"],
    ["downloaders/snackvideo", "GET"],
    ["downloaders/soundcloud", "GET"],
    ["downloaders/threads", "GET"],
    ["downloaders/xiaohongshu", "GET"],
    ["downloaders/xiaohongshu-profile", "GET"],
    ["downloaders/github", "GET"],
    ["downloaders/mediafire", "GET"],
    ["tools/jpg2png", "POST"],
    ["tools/png2jpg", "POST"],
    ["tools/upscale", "POST"],
    ["tools/ocr", "POST"],
    ["tools/headweb", "GET"],
    ["tools/ssweb", "GET"],
    ["tools/domain", "GET"],
    ["tools/lyrics", "GET"],
    ["tools/iqc", "GET"],
    ["tools/whatsapp-edge", "GET"],
    ["tools/aesthetic", "GET"],
    ["tools/brat", "GET"],
    ["tools/bratvid", "GET"],
    ["stalks/minecraft-server", "GET"],
    ["stalks/roblox", "GET"],
    ["stalks/pin", "GET"],
    ["funs/jokes", "GET"],
    ["searchs/tiktok", "GET"],
    ["searchs/nasa", "GET"],
    ["searchs/pin", "GET"],
    ["searchs/pin-video", "GET"],
    ["searchs/pin-pin", "GET"],
    ["searchs/pin-home", "GET"]
];

class LekzaError extends Error {
    constructor(message, props = {}) {
        super(message);
        this.name = "LekzaError";
        Object.assign(this, props);
    }
}

const isPlainObject = (v) => v !== null && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype;
const isBinary = (v) => Buffer.isBuffer(v) || v instanceof Uint8Array || v instanceof ArrayBuffer || (typeof Blob !== "undefined" && v instanceof Blob);
const sanitize = (s) => String(s).replace(/[\\/:*?"<>|\u0000-\u001f]/g, "").replace(/\s+/g, " ").trim();

const MIME = { ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp" };

function sniff(buf) {
    const b = Buffer.from(buf.buffer, buf.byteOffset, Math.min(buf.byteLength, 16));
    if (b.length >= 4 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return ["image/png", "image.png"];
    if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return ["image/jpeg", "image.jpg"];
    if (b.length >= 12 && b.toString("ascii", 0, 4) === "RIFF" && b.toString("ascii", 8, 12) === "WEBP") return ["image/webp", "image.webp"];
    if (b.length >= 4 && b.toString("ascii", 0, 3) === "GIF") return ["image/gif", "image.gif"];
    return ["application/octet-stream", "image"];
}

function buildRegistry(list) {
    const rank = (p) => {
        const i = CATEGORY_ORDER.indexOf(p.split("/")[0]);
        return i === -1 ? 99 : i;
    };
    const sorted = [...list].sort((a, b) => rank(a[0]) - rank(b[0]));
    const map = new Map();
    for (const [p, method] of sorted) {
        const clean = p.replace(/^\/?(api\/)?/, "");
        const ep = { path: `/api/${clean}`, method: String(method || "GET").toUpperCase(), name: clean.split("/").pop() };
        for (const key of [ep.name, clean]) if (!map.has(key)) map.set(key, ep);
    }
    return map;
}

function createClient(opts = {}) {
    const env = process.env;
    const state = {
        token: opts.token ?? env.LEKZASOFT_API_KEY ?? env.LEKZA_API_KEY ?? DEFAULT_TOKEN,
        baseUrl: String(opts.baseUrl ?? env.LEKZASOFT_API_URL ?? DEFAULT_BASE_URL).replace(/\/+$/, ""),
        timeout: Number(opts.timeout) || DEFAULT_TIMEOUT,
        registry: buildRegistry(BUILTIN),
        synced: false,
    };

    function resolve(name, methodOverride) {
        let key = String(name).trim().replace(/^\/+/, "").replace(/^api\//, "").toLowerCase();
        key = key.replace(/^search\//, "searchs/").replace(/^download\//, "downloaders/").replace(/^stalk\//, "stalks/").replace(/^tool\//, "tools/").replace(/^fun\//, "funs/");
        if (ALIASES[key]) key = ALIASES[key];
        const hit = state.registry.get(key);
        if (hit) return methodOverride ? { ...hit, method: String(methodOverride).toUpperCase() } : hit;
        // Path langsung yang belum ada di daftar (mis. "tools/removebg")
        if (/^[a-z0-9_-]+\/[a-z0-9_\/-]+$/.test(key)) {
            return { path: `/api/${key}`, method: String(methodOverride || "GET").toUpperCase(), name: key.split("/").pop(), direct: true };
        }
        return null;
    }

    async function sync() {
        const res = await fetch(`${state.baseUrl}/id/endpoints.js`, { signal: AbortSignal.timeout(15000) });
        if (!res.ok) throw new LekzaError(`Gagal mengambil daftar endpoint (HTTP ${res.status})`, { status: res.status });
        const text = await res.text();
        const m = /=\s*(\[[\s\S]*\])\s*;?\s*$/.exec(text);
        if (!m) throw new LekzaError("Format daftar endpoint tidak dikenali");
        const list = JSON.parse(m[1]).map((e) => [String(e.path), String(e.method || "GET")]);
        if (!list.length) throw new LekzaError("Daftar endpoint kosong");
        state.registry = buildRegistry(list);
        state.synced = true;
        return endpoints();
    }

    function endpoints() {
        const seen = new Set();
        const out = [];
        for (const ep of state.registry.values()) {
            if (seen.has(ep.path)) continue;
            seen.add(ep.path);
            out.push({ name: ep.name, path: ep.path, method: ep.method });
        }
        return out;
    }

    async function toForm(input) {
        let blob;
        let name = "image";
        if (typeof Blob !== "undefined" && input instanceof Blob) {
            blob = input;
            name = input.name || sniff(Buffer.from(await input.slice(0, 16).arrayBuffer()))[1];
        } else if (isBinary(input)) {
            const buf = input instanceof ArrayBuffer ? Buffer.from(input) : input;
            const [type, fname] = sniff(buf);
            blob = new Blob([buf], { type });
            name = fname;
        } else if (typeof input === "string" && /^https?:\/\//i.test(input)) {
            const r = await fetch(input, { signal: AbortSignal.timeout(60000) });
            if (!r.ok) throw new LekzaError(`Gagal mengunduh gambar dari URL (HTTP ${r.status})`, { status: r.status });
            const buf = Buffer.from(await r.arrayBuffer());
            const [type, fname] = sniff(buf);
            blob = new Blob([buf], { type: r.headers.get("content-type") || type });
            name = path.basename(new URL(input).pathname) || fname;
        } else if (typeof input === "string") {
            let buf;
            try {
                buf = await fs.promises.readFile(input);
            } catch (e) {
                throw new LekzaError(`File gambar tidak bisa dibaca: ${input}`, { cause: e });
            }
            const ext = path.extname(input).toLowerCase();
            blob = new Blob([buf], { type: MIME[ext] || sniff(buf)[0] });
            name = path.basename(input);
        } else {
            throw new LekzaError("Endpoint ini butuh gambar: kirim path file, URL, Buffer, atau Blob");
        }
        const form = new FormData();
        form.append("image", blob, name);
        return form;
    }

    async function downloadFile(source, dir = ".", dlOpts = {}) {
        const result = typeof source === "string" ? { file: source } : source;
        const url = result && result.file;
        if (typeof url !== "string" || !/^https?:\/\//i.test(url)) {
            throw new LekzaError("Hasil ini tidak punya link file untuk diunduh");
        }
        const outDir = path.resolve(dir === true ? "downloads" : dir);
        await fs.promises.mkdir(outDir, { recursive: true });

        const u = new URL(url);
        const base = decodeURIComponent(path.basename(u.pathname)) || "file";
        const ext = path.extname(base);
        const title = result.cleanTitle || result.title;
        let name = dlOpts.filename ? path.basename(String(dlOpts.filename)) : title && ext && sanitize(title) ? sanitize(title).slice(0, 80) + ext : sanitize(base) || "file";

        if (!dlOpts.overwrite) {
            const parsed = path.parse(name);
            let n = 0;
            while (fs.existsSync(path.join(outDir, name))) name = `${parsed.name} (${++n})${parsed.ext}`;
        }
        const finalPath = path.join(outDir, name);
        const tmp = `${finalPath}.part`;

        let res;
        try {
            res = await fetch(url, { signal: dlOpts.signal ?? AbortSignal.timeout(Number(dlOpts.timeout) || state.timeout) });
        } catch (e) {
            throw new LekzaError(`Gagal mengunduh file: ${e.message}`, { cause: e });
        }
        if (!res.ok || !res.body) throw new LekzaError(`Gagal mengunduh file (HTTP ${res.status}). File di server hanya tersedia beberapa menit.`, { status: res.status });
        try {
            await pipeline(Readable.fromWeb(res.body), fs.createWriteStream(tmp));
            await fs.promises.rename(tmp, finalPath);
        } catch (e) {
            await fs.promises.rm(tmp, { force: true });
            throw new LekzaError(`Gagal menyimpan file: ${e.message}`, { cause: e });
        }
        return finalPath;
    }

    async function api(endpoint, input, options = {}) {
        if (typeof endpoint !== "string" || !endpoint.trim()) {
            throw new LekzaError('Nama endpoint wajib diisi, contoh: api("play", "judul lagu")');
        }
        options = options || {};

        let ep = resolve(endpoint, options.method);
        if (!ep || ep.direct) {
            if (!state.synced) {
                try {
                    await sync();
                    ep = resolve(endpoint, options.method) || ep;
                } catch {
                    /* offline atau format berubah, pakai daftar bawaan */
                }
            }
        }
        if (!ep) {
            throw new LekzaError(`Endpoint "${endpoint}" tidak dikenal. Lihat daftar lewat api.endpoints()`, { code: "UNKNOWN_ENDPOINT" });
        }

        const params = {};
        let upload = null;
        if (isPlainObject(input)) {
            Object.assign(params, input);
        } else if (input !== undefined && input !== null) {
            if (ep.method === "POST") upload = input;
            else params.text = String(input);
        }
        for (const [k, v] of Object.entries(options)) {
            if (!RESERVED.has(k) && v !== undefined && v !== null) params[k] = v;
        }
        if (ep.method === "POST" && !upload && params.image !== undefined) {
            upload = params.image;
            delete params.image;
        }

        const qs = new URLSearchParams();
        for (const [k, v] of Object.entries(params)) qs.set(k, String(v));
        const url = `${state.baseUrl}${ep.path}${qs.toString() ? "?" + qs : ""}`;

        const headers = {
            "x-api-key": options.token ?? state.token,
            accept: "application/json",
            "user-agent": `lekzasoft-api/${VERSION}`,
        };
        const init = { method: ep.method, headers, signal: options.signal ?? AbortSignal.timeout(Number(options.timeout) || state.timeout) };
        if (ep.method === "POST") {
            if (upload === null) throw new LekzaError("Endpoint ini butuh gambar: kirim path file, URL, Buffer, atau Blob");
            init.body = await toForm(upload);
        }

        let res;
        try {
            res = await fetch(url, init);
        } catch (e) {
            const timedOut = e && (e.name === "TimeoutError" || e.name === "AbortError");
            throw new LekzaError(timedOut ? "Request timeout" : `Tidak bisa terhubung ke API: ${e.cause?.code || e.message}`, { cause: e, code: timedOut ? "TIMEOUT" : "NETWORK", endpoint: ep.path });
        }

        const raw = await res.text();
        let json;
        try {
            json = JSON.parse(raw);
        } catch {
            /* bukan JSON */
        }
        if (!res.ok || !json || json.status === false) {
            const retryAfter = Number(res.headers.get("retry-after")) || json?.retry_after || undefined;
            throw new LekzaError(json?.message || `HTTP ${res.status}`, {
                status: res.status,
                body: json ?? raw.slice(0, 300),
                retryAfter,
                endpoint: ep.path,
                code: res.status === 429 ? "RATE_LIMITED" : undefined,
            });
        }
        if (options.raw) return json;

        const result = json && Object.prototype.hasOwnProperty.call(json, "result") ? json.result : json;
        if (result && typeof result === "object" && !Array.isArray(result)) {
            Object.defineProperty(result, "download", {
                value: (dir, dlOpts) => downloadFile(result, dir, dlOpts),
                enumerable: false,
                configurable: true,
            });
            if (options.download) result.path = await downloadFile(result, options.download, { filename: options.filename });
        }
        return result;
    }

    api.create = createClient;
    api.sync = sync;
    api.endpoints = endpoints;
    api.download = downloadFile;
    api.config = (next) => {
        if (next && typeof next === "object") {
            if (next.token !== undefined) state.token = next.token;
            if (next.baseUrl !== undefined) {
                state.baseUrl = String(next.baseUrl).replace(/\/+$/, "");
                state.synced = false;
            }
            if (next.timeout !== undefined) state.timeout = Number(next.timeout) || DEFAULT_TIMEOUT;
        }
        return { token: state.token === DEFAULT_TOKEN ? "PUBLIC-KEY (bawaan)" : "***", baseUrl: state.baseUrl, timeout: state.timeout };
    };
    api.LekzaError = LekzaError;
    api.version = VERSION;
    api.default = api;
    return api;
}

module.exports = createClient();
