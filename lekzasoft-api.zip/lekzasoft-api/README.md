# @lekzasoft/api

Client resmi [Lekzasoft API](https://api.lekzasoft.web.id). Satu fungsi buat semua endpoint: downloader (YouTube, TikTok, Instagram, GitHub, dll), tools gambar, search, dan lainnya. Tanpa dependensi, butuh Node.js 18+.

```bash
npm install @lekzasoft/api
```

## Pakai

```js
import api from "@lekzasoft/api";

const play = await api("play", "dewa 19 kangen");
console.log(play.title, play.file);

// simpan filenya ke folder
const path = await play.download("./musik");
```

CommonJS juga bisa: `const api = require("@lekzasoft/api")`.

### Download otomatis

```js
const video = await api("ytmp4", "https://youtu.be/xxxx", { download: "./video" });
console.log(video.path); // ./video/Judul Video.mp4
```

Link `file` dari server hanya aktif beberapa menit, jadi unduh segera.

### Parameter tambahan

Opsi selain yang dikenal modul diteruskan sebagai query:

```js
await api("pin", "kucing", { limit: 10 });
await api("ssweb", "https://google.com", { device: "mobile" });
await api("iqc", "halo", { time: "12:00", reply: "hai", sender: "Budi" });
```

### Endpoint upload gambar

`jpg2png`, `png2jpg`, `upscale`, `ocr` menerima path file, URL, Buffer, atau Blob:

```js
const ocr = await api("ocr", "./foto.png");
const big = await api("upscale", fs.readFileSync("./kecil.jpg"));
```

## Token

Bawaan modul memakai key publik `PUBLIC-KEY` (kuota bersama, bisa habis kapan saja). Untuk pemakaian serius, login di dashboard dan pakai token sendiri:

```js
api.config({ token: "lk_xxxxx" });
// atau lewat environment: LEKZASOFT_API_KEY=lk_xxxxx
// atau client terpisah:
const mine = api.create({ token: "lk_xxxxx" });
```

## Error

Semua kegagalan melempar `LekzaError` dengan `status`, `code`, dan `retryAfter` (kalau kena rate limit):

```js
try {
  await api("ytmp3", link);
} catch (e) {
  if (e.code === "RATE_LIMITED") console.log("coba lagi dalam", e.retryAfter, "detik");
  else console.log(e.status, e.message);
}
```

## Opsi

| Opsi | Fungsi |
| --- | --- |
| `download` | Folder tujuan, file hasil otomatis diunduh. Path-nya ada di `hasil.path`. |
| `filename` | Nama file kalau memakai `download`. |
| `token` | Token khusus untuk satu request. |
| `timeout` | Batas waktu (ms). Bawaan 10 menit. |
| `raw` | Kembalikan seluruh JSON respons, bukan hanya `result`. |
| `method` | Paksa GET/POST untuk endpoint yang belum ada di daftar. |

Fungsi lain: `api.endpoints()`, `api.sync()` (perbarui daftar dari server, otomatis dipanggil kalau nama endpoint belum dikenal), `api.download(url, dir)`.

Kalau ada nama endpoint ganda (mis. `tiktok` ada di downloader dan search), yang dipakai downloader. Untuk yang lain tulis lengkap: `api("searchs/tiktok", "dance")`.

## Daftar endpoint

| Nama | Method | Path |
| --- | --- | --- |
| `allinone` | GET | `downloaders/allinone` |
| `play` | GET | `downloaders/play` |
| `yts` | GET | `downloaders/yts` |
| `ytmp3` | GET | `downloaders/ytmp3` |
| `ytmp4` | GET | `downloaders/ytmp4` |
| `ytmp3v2` | GET | `downloaders/ytmp3v2` |
| `ytmp4v2` | GET | `downloaders/ytmp4v2` |
| `tiktok` | GET | `downloaders/tiktok` |
| `instagram` | GET | `downloaders/instagram` |
| `facebook` | GET | `downloaders/facebook` |
| `x` | GET | `downloaders/x` |
| `reddit` | GET | `downloaders/reddit` |
| `twitch` | GET | `downloaders/twitch` |
| `capcut` | GET | `downloaders/capcut` |
| `cocofun` | GET | `downloaders/cocofun` |
| `douyin` | GET | `downloaders/douyin` |
| `gdrive` | GET | `downloaders/gdrive` |
| `kuaishou` | GET | `downloaders/kuaishou` |
| `snackvideo` | GET | `downloaders/snackvideo` |
| `soundcloud` | GET | `downloaders/soundcloud` |
| `threads` | GET | `downloaders/threads` |
| `xiaohongshu` | GET | `downloaders/xiaohongshu` |
| `xiaohongshu-profile` | GET | `downloaders/xiaohongshu-profile` |
| `github` | GET | `downloaders/github` |
| `mediafire` | GET | `downloaders/mediafire` |
| `jpg2png` | POST | `tools/jpg2png` |
| `png2jpg` | POST | `tools/png2jpg` |
| `upscale` | POST | `tools/upscale` |
| `ocr` | POST | `tools/ocr` |
| `headweb` | GET | `tools/headweb` |
| `ssweb` | GET | `tools/ssweb` |
| `domain` | GET | `tools/domain` |
| `lyrics` | GET | `tools/lyrics` |
| `iqc` | GET | `tools/iqc` |
| `whatsapp-edge` | GET | `tools/whatsapp-edge` |
| `aesthetic` | GET | `tools/aesthetic` |
| `brat` | GET | `tools/brat` |
| `bratvid` | GET | `tools/bratvid` |
| `tiktok` | GET | `searchs/tiktok` |
| `nasa` | GET | `searchs/nasa` |
| `pin` | GET | `searchs/pin` |
| `pin-video` | GET | `searchs/pin-video` |
| `pin-pin` | GET | `searchs/pin-pin` |
| `pin-home` | GET | `searchs/pin-home` |
| `minecraft-server` | GET | `stalks/minecraft-server` |
| `roblox` | GET | `stalks/roblox` |
| `pin` | GET | `stalks/pin` |
| `jokes` | GET | `funs/jokes` |

Satu request memotong kuota sesuai harga endpoint-nya, dan kuota otomatis kembali kalau request gagal. Dokumentasi lengkap: https://api.lekzasoft.web.id/id/docs

## Lisensi

MIT
