import api from "./index.cjs";

export default api;
export const { create, sync, endpoints, download, config, LekzaError, version } = api;
