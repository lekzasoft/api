export interface DownloadOptions {
    /** Nama file hasil. Default: judul + ekstensi asli. */
    filename?: string;
    /** Timpa file kalau namanya sudah ada (default: tambah " (1)"). */
    overwrite?: boolean;
    timeout?: number;
    signal?: AbortSignal;
}

export interface CallOptions {
    /** Simpan file hasil otomatis ke folder ini (true = ./downloads). Path-nya ada di `hasil.path`. */
    download?: string | boolean;
    /** Nama file kalau memakai `download`. */
    filename?: string;
    /** Token khusus untuk request ini. */
    token?: string;
    /** Batas waktu request (ms). Default 10 menit. */
    timeout?: number;
    signal?: AbortSignal;
    /** Kembalikan seluruh respons JSON, bukan hanya `result`. */
    raw?: boolean;
    /** Paksa method untuk endpoint yang belum ada di daftar. */
    method?: "GET" | "POST";
    /** Parameter lain diteruskan sebagai query, mis. { limit: 10 }, { device: "mobile" }. */
    [param: string]: unknown;
}

export interface Downloadable {
    /** Unduh `file` hasil ke folder `dir`. Mengembalikan path file. */
    download(dir?: string | boolean, options?: DownloadOptions): Promise<string>;
    /** Terisi kalau memakai opsi `download`. */
    path?: string;
}

export interface MediaResult extends Downloadable {
    id?: string;
    title?: string;
    cleanTitle?: string;
    thumbnail?: string;
    duration?: string | number;
    duration_string?: string;
    channel?: string;
    uploader?: string;
    views?: number;
    url?: string;
    /** Link file hasil (di server, aktif beberapa menit). */
    file: string;
    lyrics?: string;
    [key: string]: any;
}

export interface GithubResult extends Downloadable {
    owner: string;
    repo: string;
    branch: string;
    file: string;
    file_name: string;
    file_size: string;
    file_size_bytes: number;
    [key: string]: any;
}

export type Result<T = any> = (T extends object ? T & Downloadable : T);

export type KnownEndpoint =
    | "play" | "ytmp3" | "ytmp4" | "ytmp3v2" | "ytmp4v2" | "yts"
    | "tiktok" | "instagram" | "facebook" | "x" | "twitter" | "reddit" | "twitch"
    | "capcut" | "cocofun" | "douyin" | "gdrive" | "kuaishou" | "snackvideo"
    | "soundcloud" | "threads" | "xiaohongshu" | "xiaohongshu-profile"
    | "github" | "mediafire" | "allinone"
    | "jpg2png" | "png2jpg" | "upscale" | "ocr" | "headweb" | "ssweb" | "domain"
    | "lyrics" | "iqc" | "whatsapp-edge" | "aesthetic" | "brat" | "bratvid"
    | "minecraft-server" | "roblox" | "nasa" | "jokes"
    | "pin" | "pin-video" | "pin-pin" | "pin-home"
    | (string & {});

export type ImageInput = string | Buffer | Uint8Array | ArrayBuffer | Blob;

export interface EndpointInfo {
    name: string;
    path: string;
    method: "GET" | "POST";
}

export interface ClientOptions {
    token?: string;
    baseUrl?: string;
    timeout?: number;
}

export class LekzaError extends Error {
    status?: number;
    code?: "RATE_LIMITED" | "TIMEOUT" | "NETWORK" | "UNKNOWN_ENDPOINT" | string;
    /** Detik sebelum boleh mencoba lagi (429). */
    retryAfter?: number;
    endpoint?: string;
    body?: unknown;
}

export interface Api {
    (endpoint: "play" | "ytmp3" | "ytmp4" | "ytmp3v2" | "ytmp4v2", input: string | Record<string, unknown>, options?: CallOptions): Promise<MediaResult>;
    (endpoint: "github", input: string | Record<string, unknown>, options?: CallOptions): Promise<GithubResult>;
    <T = any>(endpoint: KnownEndpoint, input?: string | ImageInput | Record<string, unknown>, options?: CallOptions): Promise<Result<T>>;

    create(options?: ClientOptions): Api;
    config(options?: ClientOptions): { token: string; baseUrl: string; timeout: number };
    /** Perbarui daftar endpoint dari server (otomatis dipanggil kalau nama endpoint belum dikenal). */
    sync(): Promise<EndpointInfo[]>;
    endpoints(): EndpointInfo[];
    download(source: string | { file: string; title?: string }, dir?: string | boolean, options?: DownloadOptions): Promise<string>;
    LekzaError: typeof LekzaError;
    version: string;
    default: Api;
}

declare const api: Api;
export default api;
export const create: Api["create"];
export const config: Api["config"];
export const sync: Api["sync"];
export const endpoints: Api["endpoints"];
export const download: Api["download"];
export const version: string;
