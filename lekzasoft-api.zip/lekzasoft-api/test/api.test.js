import test from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";
import api, { create, LekzaError } from "../index.mjs";

const require = createRequire(import.meta.url);
const PNG = Buffer.from("89504e470d0a1a0a0000000d49484452", "hex");

let server;
let base;
const seen = [];

test.before(async () => {
    server = http.createServer((req, res) => {
        const url = new URL(req.url, "http://x");
        let body = [];
        req.on("data", (c) => body.push(c));
        req.on("end", () => {
            body = Buffer.concat(body);
            seen.push({ method: req.method, path: url.pathname, query: Object.fromEntries(url.searchParams), key: req.headers["x-api-key"], ct: req.headers["content-type"], body });
            const json = (code, obj, headers = {}) => {
                res.writeHead(code, { "content-type": "application/json", ...headers });
                res.end(JSON.stringify(obj));
            };
            if (url.pathname === "/api/downloaders/play") {
                return json(200, { status: true, result: { title: "Dewa 19 - Kangen (Official)", cleanTitle: "Dewa 19 - Kangen", file: `${base}/assets/abc123.webm` } });
            }
            if (url.pathname === "/assets/abc123.webm") {
                res.writeHead(200, { "content-type": "audio/webm" });
                return res.end(Buffer.alloc(4096, 7));
            }
            if (url.pathname === "/api/searchs/pin") return json(200, { status: true, result: [{ id: 1 }, { id: 2 }] });
            if (url.pathname === "/api/tools/ocr" && req.method === "POST") {
                const ok = /multipart\/form-data/.test(req.headers["content-type"] || "") && body.includes('name="image"');
                return ok ? json(200, { status: true, result: { text: "halo" } }) : json(400, { status: false, message: "image required" });
            }
            if (url.pathname === "/api/downloaders/ytmp4") return json(429, { status: false, message: "Terlalu cepat", retry_after: 12 }, { "retry-after": "12" });
            if (url.pathname === "/api/downloaders/gdrive") return json(500, { status: false, message: "gagal" });
            if (url.pathname === "/api/downloaders/newfeature") return json(200, { status: true, result: { ok: true } });
            if (url.pathname === "/id/endpoints.js") {
                const list = [
                    { path: "/api/downloaders/play", method: "GET" },
                    { path: "/api/downloaders/newfeature", method: "GET" },
                ];
                res.writeHead(200, { "content-type": "text/javascript" });
                return res.end(`/* x */\nwindow.LEKZA_ENDPOINTS = ${JSON.stringify(list, null, 2)};\n`);
            }
            json(404, { status: false, message: "Not found" });
        });
    });
    await new Promise((r) => server.listen(0, "127.0.0.1", r));
    base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

const client = (extra = {}) => create({ baseUrl: base, token: "TOKEN-TES", ...extra });

test("api(\"play\", teks): result langsung bisa dipakai, token lewat header", async () => {
    const play = await client()("play", "dewa 19 kangen");
    assert.equal(play.title, "Dewa 19 - Kangen (Official)");
    assert.match(play.file, /abc123\.webm$/);
    const last = seen.at(-1);
    assert.equal(last.query.text, "dewa 19 kangen");
    assert.equal(last.key, "TOKEN-TES");
    assert.equal(Object.keys(play).includes("download"), false); // helper tidak ikut JSON
});

test("play.download(dir) menyimpan file dengan nama dari judul", async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "lz-"));
    const play = await client()("play", "x");
    const p = await play.download(dir);
    assert.equal(path.basename(p), "Dewa 19 - Kangen.webm");
    assert.equal(fs.statSync(p).size, 4096);
    const p2 = await play.download(dir); // jangan menimpa
    assert.equal(path.basename(p2), "Dewa 19 - Kangen (1).webm");
    assert.equal(fs.readdirSync(dir).some((f) => f.endsWith(".part")), false);
});

test("opsi download otomatis mengunduh dan mengisi .path", async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "lz-"));
    const play = await client()("play", "x", { download: dir, filename: "lagu.webm" });
    assert.equal(play.path, path.join(dir, "lagu.webm"));
    assert.ok(fs.existsSync(play.path));
});

test("opsi lain diteruskan sebagai query, nama bentrok dipilih sesuai prioritas", async () => {
    const r = await client()("pin", "kucing", { limit: 5 });
    assert.equal(r.length, 2);
    const last = seen.at(-1);
    assert.equal(last.path, "/api/searchs/pin");
    assert.equal(last.query.limit, "5");
});

test("endpoint upload: path file, Buffer, dan objek { image } dikirim multipart", async () => {
    const c = client();
    const file = path.join(os.tmpdir(), "lz-test.png");
    fs.writeFileSync(file, PNG);
    assert.equal((await c("ocr", file)).text, "halo");
    assert.equal((await c("ocr", PNG)).text, "halo");
    assert.equal((await c("ocr", { image: PNG })).text, "halo");
    await assert.rejects(() => c("ocr"), /butuh gambar/);
});

test("error API menjadi LekzaError lengkap dengan status dan retryAfter", async () => {
    await assert.rejects(
        () => client()("ytmp4", "x"),
        (e) => e instanceof LekzaError && e.status === 429 && e.code === "RATE_LIMITED" && e.retryAfter === 12 && e.message === "Terlalu cepat"
    );
    await assert.rejects(() => client()("gdrive", "x"), (e) => e.status === 500 && e.message === "gagal");
});

test("endpoint belum dikenal: otomatis sync daftar dari server, baru gagal kalau memang tidak ada", async () => {
    const c = client();
    assert.equal((await c("newfeature", "x")).ok, true);
    await assert.rejects(() => c("tidak-ada", "x"), (e) => e.code === "UNKNOWN_ENDPOINT");
});

test("server mati: error jelas, bukan crash", async () => {
    const c = create({ baseUrl: "http://127.0.0.1:1", timeout: 3000 });
    await assert.rejects(() => c("play", "x"), (e) => e instanceof LekzaError && e.code === "NETWORK");
});

test("raw: true mengembalikan JSON utuh", async () => {
    const r = await client()("play", "x", { raw: true });
    assert.equal(r.status, true);
    assert.ok(r.result.title);
});

test("CommonJS require() juga jalan dan token bawaan PUBLIC-KEY", () => {
    const cjs = require("../index.cjs");
    assert.equal(typeof cjs, "function");
    assert.equal(cjs.config().token, "PUBLIC-KEY (bawaan)");
    assert.ok(cjs.endpoints().some((e) => e.path === "/api/downloaders/play"));
});
